// 变量isVip表示：是否为会员
let isVip: boolean = false

// 需求：如果是会员，就打印 '看完整电影'
if (isVip) {
  console.log('看完整电影')
}