// 判断 5 大于 3 吗？
// 如果大于，就得到：'大于' ；否则，得到：'小于'
let result: string = 5 < 3 ? '大于' : '小于'
console.log(result)