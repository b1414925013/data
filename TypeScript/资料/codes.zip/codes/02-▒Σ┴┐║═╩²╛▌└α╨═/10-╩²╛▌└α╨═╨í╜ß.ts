// 判断以下代码是否正确：

// 错误的
// let age: number = '18'

// 错误的
// let isStudying: boolean = 'true'
