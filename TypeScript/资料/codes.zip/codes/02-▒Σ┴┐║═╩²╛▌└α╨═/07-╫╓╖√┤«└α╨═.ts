console.log('Hello TS')
console.log("Hello TS")

// 声明字符串类型的变量
let food: string = '糖葫芦'
console.log(food)