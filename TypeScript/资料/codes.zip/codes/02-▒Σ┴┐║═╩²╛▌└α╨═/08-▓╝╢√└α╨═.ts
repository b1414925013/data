// 真
let isStudying: boolean = true

// 假
let isPlayingGame: boolean = false

console.log(isStudying)
console.log(isPlayingGame)