// 变量的基本使用：

// // 第一步：声明变量并指定类型
// let age: number

// // 第二步：给变量赋值
// age = 18
// console.log(age)

// // 变量是可以变化的
// age = 19
// console.log(age)


// 简化方式：声明变量的同时就赋值
let age: number = 20
console.log(age)