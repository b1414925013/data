// 以下示例中变量名称是否正确：

// let 2b 
// let $name 
// let first_name
// let @email 

let age: number = 18
let Age: number = 20
console.log(age)
console.log(Age)