// 整数
let size: number = 18

// 小数
let score: number = 99.9

console.log(size)
console.log(score)

// 正数
let salary: number = +10000

// 负数
let salary1: number = -2000

console.log(salary)
console.log(salary1)