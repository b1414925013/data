// // undefined
// let u: undefined = undefined

// null
let n: null = null

// console.log(u)
// console.log(n)

let u1: undefined
console.log(u1)