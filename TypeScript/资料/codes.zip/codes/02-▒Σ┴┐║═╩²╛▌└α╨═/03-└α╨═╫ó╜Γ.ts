let age: number = 18

// 错误演示：
age = 'Hello TS'