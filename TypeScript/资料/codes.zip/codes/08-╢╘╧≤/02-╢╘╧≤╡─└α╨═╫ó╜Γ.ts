// 此处的{}表示对象的类型注解
let person: {
  name: string;
  age: number
}

// 此处的{}表示ts中的对象
person = {
  name: '刘老师',
  age: 18
}