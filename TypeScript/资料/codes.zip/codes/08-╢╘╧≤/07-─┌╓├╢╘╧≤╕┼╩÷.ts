console.log(Math.max(1, 3, 2));
// expected output: 3