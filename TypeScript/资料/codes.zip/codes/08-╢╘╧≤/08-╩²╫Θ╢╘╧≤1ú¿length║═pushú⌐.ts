let songs: string[] = ['五环之歌', '探清水河', '晴天']

// length 属性：
// console.log(songs.length)

// push 方法：
let len: number = songs.push('痒')
console.log(songs, len)