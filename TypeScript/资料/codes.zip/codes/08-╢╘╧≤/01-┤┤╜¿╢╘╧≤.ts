let person = {
  name: '刘老师',
  age: 18,
  sayHi: function () {
    console.log('大家好，我是一个方法')
  }
}