console.log('周杰' + '伦')

console.log(1 + '2')
console.log('1' + 2)