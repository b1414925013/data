// 实现数值 2 和 3 的算术运算：

// 加
console.log(2 + 3)
// 减
console.log(2 - 3)
// 乘
console.log(2 * 3)
// 除
console.log(2 / 3)
