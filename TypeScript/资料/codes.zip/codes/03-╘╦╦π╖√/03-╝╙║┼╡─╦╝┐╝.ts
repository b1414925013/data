// console.log(2 - '1')
// console.log('2' - 1)

console.log(2 - +'1')

let age: number = +'18'