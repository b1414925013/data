// 与：
// console.log(true && false)
// console.log(2 > 1 && 2 >= 2)

// 或：
// console.log(true || false)
// console.log(3 < 2 || 1 <= 2)

// 非：
console.log(!true)
console.log(!false || false)