let age: number = 18

// age = age + 1
// 简化形式
// age += 1

// age = age - 1
age -= 1

console.log(age)