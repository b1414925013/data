let age: number = 18

// age++
age-- // age -= 1

console.log(age)