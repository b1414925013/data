// // 大于
// console.log(1 > 2)
// // 大于等于
// console.log(3 >= 2)
// // 小于
// console.log(1 < 2)
// // 小于等于
// console.log(3 <= 2)

// 相等
let num1: number = 3
let num2: number = 4
// console.log(3 === 4)
// console.log(num1 === num2)
// 不相等
// console.log(3 !== 4)
console.log(num1 !== num2)
