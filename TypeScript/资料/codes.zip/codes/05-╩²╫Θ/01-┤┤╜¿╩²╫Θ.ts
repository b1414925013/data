// 创建数组：
// let names: string[] = ['迪丽热巴', '古力娜扎', '1']
// console.log(names)

// 第二种方式：
let names: string[] = new Array('迪丽热巴', '古力娜扎', '1')
console.log(names)