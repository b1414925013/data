// 数组内容： 煎饼 馒头 米饭

// 数组长度
let foods: string[] = ['煎饼', '馒头', '米饭', '包子']
console.log(foods.length)