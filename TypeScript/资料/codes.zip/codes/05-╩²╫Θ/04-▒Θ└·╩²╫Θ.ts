// 遍历数组：

let nums: number[] = [100, 200, 300, 400]

// 使用 for 循环遍历数组，取出数组中的每一项元素
// for (let i: number = 0; i <= nums.length - 1; i++) {
//   console.log(nums[i])
// }

// 简化判断条件
for (let i: number = 0; i < nums.length; i++) {
  console.log(nums[i])
}