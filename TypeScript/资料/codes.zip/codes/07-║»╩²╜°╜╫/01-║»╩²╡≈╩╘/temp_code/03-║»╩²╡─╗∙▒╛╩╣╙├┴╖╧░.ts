// 创建一个函数（sum），用来计算两个数字的和（比如：10 和 20）
function sum() {
  let num1: number = 10
  let num2: number = 20
  let result: number = num1 + num2
  console.log(result)
}

sum()