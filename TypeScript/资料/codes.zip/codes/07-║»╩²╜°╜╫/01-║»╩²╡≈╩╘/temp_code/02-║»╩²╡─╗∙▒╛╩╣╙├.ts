// 函数的基本使用：
// 1 声明函数
function sing(songName: string) {
  console.log(songName)
}

// 2 调用函数
sing('五环之歌')
