// 函数参数

// 1 声明函数
function sing() {
  console.log('五环之歌')
}

// 2
// 第一次调用函数
sing()
// 第二次调用函数
sing()
