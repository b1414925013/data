// let age = 1

// // 函数表达式
// let fn: () => void = function() {}

// interface IObj {
//   say: () => void
// }

// let obj = {
//   say: function() {}
// }

// // 枚举
// enum GenderType {
//   Male = 'male',
//   Female = 'female',
//   Unkown = 'unknow'
// }

// interface IUser {
//   gender: GenderType
// }

// let o: IUser = {
//   gender: GenderType.Male
// }

// console.log(o)

// // as 类型断言
// interface IObj1 {
//   name: string
// }

// let o1 = {} as IObj1
// o1.name = ''

console.log('开始')

function eat() {
  console.log('吃早饭')
  console.log('吃午饭')
}

eat()

console.log('结束')
