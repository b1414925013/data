console.log('1 准备开始执行 for 循环')

for (let i: number = 1; i <= 3; i++) {
  console.log('...一锅装不下')
}

console.log('2 for 循环执行结束')