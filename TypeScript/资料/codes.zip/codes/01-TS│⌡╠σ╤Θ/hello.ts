// 这句代码用来打印一段文本内容
// console.log('泡枸杞')
// 快捷键：ctrl + /

/*
  这是第一行注释
  中年男人必备

  快捷键：shift + alt + a
*/
console.log('人到中年不得已')