/*
  单元格元素列表说明
*/
// 单元格元素列表
var cells = document.querySelectorAll('.cell');
// console.log(cells)
// 通过索引获取元素
// console.log(cells[0])
// console.log(cells[4])
// 使用 for 循环遍历
for (var i = 0; i < cells.length; i++) {
    console.log(cells[i]);
}
