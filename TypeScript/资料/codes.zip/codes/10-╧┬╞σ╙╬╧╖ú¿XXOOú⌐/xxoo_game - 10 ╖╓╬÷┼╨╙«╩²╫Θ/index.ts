/*
  分析判赢数组：
*/

let winsArr = [
  [0, 1, 2], [3, 4, 5]
]

// 访问数组成员
console.log(winsArr[0])
console.log(winsArr[0][2])