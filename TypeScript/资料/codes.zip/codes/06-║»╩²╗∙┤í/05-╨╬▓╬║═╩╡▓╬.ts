function sing(songName: string) {
  console.log(songName)
}

sing('五环之歌')