function fn(): number {
  return 18
}

// let result: number = fn()
// // let result: number = 18
// // 进行其他计算
// console.log(result * 10)
// console.log(result / 2)

console.log(fn() * 10)
console.log(fn() / 2)