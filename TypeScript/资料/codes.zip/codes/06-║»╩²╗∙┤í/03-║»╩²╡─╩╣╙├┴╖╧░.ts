// 创建一个函数（sum），
// 计算两个变量num1、num2的和（比如：10 和 20）


// 1 创建函数sum
function sum() {
  // 2 在函数体中，计算两个变量num1、num2的和
  let num1: number = 10
  let num2: number = 20
  let result: number = num1 + num2
  console.log(result)
}
// 3 调用函数sum
sum()