// 函数使用的两个步骤：
// 1 声明函数
function sing() {
  console.log('五环之歌')
}
// 2 调用函数
sing()