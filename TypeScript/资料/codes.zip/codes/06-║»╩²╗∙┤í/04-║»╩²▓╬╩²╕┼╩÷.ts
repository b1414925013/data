// 唱歌的函数：
// function sing() {
//   console.log('五环之歌')
// }

// sing()
// sing()

function sing(songName: string) {
  console.log(songName)
}

sing('五环之歌')
sing('探清水河')
