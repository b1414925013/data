// 获取 h1 元素：
var title = document.querySelector('#title');
// title.id
console.log(title);
console.dir(title);
// 获取 img 元素：
var img = document.querySelector('#image');
img.src = './2.jpg';
// img.id
console.dir(img);
