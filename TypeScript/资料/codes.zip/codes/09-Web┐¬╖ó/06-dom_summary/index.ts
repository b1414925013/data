// 示例：通过代码，修改页面标题
document.title = '等你下课'