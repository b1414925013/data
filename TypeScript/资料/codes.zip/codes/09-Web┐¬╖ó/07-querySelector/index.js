// 示例： 获取 id 为 title 的 DOM 元素
// let title = document.querySelector('#title')
// console.log(title)
// let title = document.querySelector('p')
// console.log(title)
var title = document.querySelector('.c1');
console.log(title);
