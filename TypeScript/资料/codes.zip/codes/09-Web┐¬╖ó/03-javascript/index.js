let person = {
  name: '刘老师',
  age: 18
}

console.log(person)