function sum(num1, num2) {
    return num1 + num2;
}
var res = sum(1, 9);
console.log('TS 代码执行了：', res, 'abc', 666);
