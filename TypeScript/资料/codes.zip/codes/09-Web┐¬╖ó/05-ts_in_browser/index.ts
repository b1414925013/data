function sum(num1: number, num2: number) {
  return num1 + num2
}

let res = sum(1, 9)
console.log('TS 代码执行了：', res, 'abc', 666)
