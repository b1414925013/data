// 示例：获取带有 .a 类名的元素列表
let list = document.querySelectorAll('.a')
console.log(list)
