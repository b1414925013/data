let age = 19
console.log(age)